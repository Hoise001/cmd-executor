Hooks.once('init', () => {
  console.log('CMD Executor: Initializing module');
  game.socket.on('module.cmd-executor', async (data, callback) => {
    console.log(`CMD Executor: Received command: ${data.command}`);
    if (!game.user.isGM) {
      console.log('CMD Executor: Non-GM user attempted to run command');
      return callback({ error: 'Only GMs can run CMD commands' });
    }
    try {
      const { exec } = require('child_process');
      console.log('CMD Executor: Executing command');
      const result = await new Promise((resolve, reject) => {
        exec(data.command, { shell: 'cmd.exe' }, (error, stdout, stderr) => {
          if (error) {
            console.log(`CMD Executor: Command error: ${error.message}`);
            return reject(error);
          }
          console.log(`CMD Executor: Command output: ${stdout || stderr}`);
          resolve(stdout || stderr);
        });
      });
      callback({ result });
    } catch (error) {
      console.log(`CMD Executor: Caught error: ${error.message}`);
      callback({ error: error.message });
    }
  });

  game.modules.get('cmd-executor').runCmd = async (command) => {
    console.log(`CMD Executor: Client requesting command: ${command}`);
    return new Promise((resolve, reject) => {
      game.socket.emit('module.cmd-executor', { command }, (response) => {
        if (response.error) {
          console.log(`CMD Executor: Socket error: ${response.error}`);
          return reject(new Error(response.error));
        }
        console.log(`CMD Executor: Socket response: ${response.result}`);
        resolve(response.result);
      });
    });
  };
});

Hooks.on('ready', () => {
  if (game.user.isGM) console.log('CMD Executor Module Ready');
});