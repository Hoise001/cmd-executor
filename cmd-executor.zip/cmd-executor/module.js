Hooks.once('init', () => {
  console.log('CMD Executor: Initializing module');

  // Verify module registration
  const module = game.modules.get('cmd-executor');
  if (!module) {
    console.error('CMD Executor: Module not registered in game.modules');
    return;
  }

  // Register API (support both runCmd and api.runCmd for compatibility)
  module.api = {
    runCmd: async (command) => {
      if (!game.user.isGM) {
        console.log('CMD Executor: Non-GM user attempted to run command');
        throw new Error('Only GMs can run CMD commands');
      }
      console.log(`CMD Executor: Client emitting command: ${command}`);
      return new Promise((resolve, reject) => {
        game.socket.emit('module.cmd-executor', { command }, (response) => {
          console.log('CMD Executor: Received socket response');
          if (response && response.error) {
            console.log(`CMD Executor: Socket error: ${response.error}`);
            return reject(new Error(response.error));
          }
          console.log(`CMD Executor: Socket success: ${response?.result || 'No result'}`);
          resolve(response?.result || '');
        });
      });
    }
  };
  // Also set runCmd directly for backward compatibility
  module.runCmd = module.api.runCmd;

  // Register socket handler
  game.socket.on('module.cmd-executor', async (data) => {
    console.log(`CMD Executor: Server received command: ${data.command}`);
    if (!game.user.isGM) {
      console.log('CMD Executor: Non-GM user on server');
      return { error: 'Only GMs can run CMD commands' };
    }
    try {
      const { exec } = require('child_process');
      console.log('CMD Executor: Executing command');
      const result = await new Promise((resolve, reject) => {
        exec(data.command, { shell: 'cmd.exe' }, (error, stdout, stderr) => {
          if (error) {
            console.log(`CMD Executor: Command error: ${error.message}`);
            return reject(error);
          }
          console.log(`CMD Executor: Command output: ${stdout || stderr}`);
          resolve(stdout || stderr);
        });
      });
      return { result };
    } catch (error) {
      console.log(`CMD Executor: Server caught error: ${error.message}`);
      return { error: error.message };
    }
  });

  console.log('CMD Executor: Socket and API registered successfully');
});

Hooks.on('ready', () => {
  if (game.user.isGM) console.log('CMD Executor: Module Ready');
  const module = game.modules.get('cmd-executor');
  if (module?.api?.runCmd || module?.runCmd) {
    console.log('CMD Executor: runCmd function is available');
  } else {
    console.error('CMD Executor: runCmd function not registered');
  }
});